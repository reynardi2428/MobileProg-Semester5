package id.ac.binus.LA02_MultipleActivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ReplyMessage extends AppCompatActivity {

    TextView tvReply;
    EditText editReply;
    Button btnReply;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply_message);

        tvReply = findViewById(R.id.tvReply);
        editReply = findViewById(R.id.editReply);
        btnReply = findViewById(R.id.btnReply);

        Intent intent = getIntent();
        String message = intent.getStringExtra("message");

        tvReply.setText(message);
    }
}